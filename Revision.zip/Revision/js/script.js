var menu = document.getElementById('menu');
menu.innerHTML = "<ul><li><a href='welcome.html'>Welcome</a></li><li><a href='index.html'>Details</a></li></ul>";

var fName = document.getElementById("fName");
var locality = document.getElementById("locality");
var telephone = document.getElementById("telephone");
var divName = document.getElementById("divName");
var divLocality = document.getElementById("divLocality");
var divTele = document.getElementById("divTele");

var imgArray = ["js/images/bmw1.JPG", "js/images/bmw2.jpg", "js/images/bmw3.jpg"];
var image = document.getElementById("image");
image.src = imgArray[0];

function changeImage()
{
    var i = imgArray.indexOf(this.getAttribute("src"));
    
    if(i < (imgArray.length-1))
        {
            i++;
            this.src = imgArray[i];
        }
    else
        {
            this.src = imgArray[0];
        }
}

image.addEventListener('click', changeImage);

function validation()
{
    if(fName.value.length < 3)
        {
            divName.innerHTML = "Name should have atleast 3 characters";
            divName.style.color = "red";
        }
    else if(fName.value.length >= 3)
        {
            divName.innerHTML = "";
        }
}

fName.addEventListener('focusout', validation);